package com.edgesharpentry.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151D31)
private val Muted = Color(0xFF9AA8C3)
private val Accent = Color(0xFF56D6B3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EdgeApp() }
    }
}

@Composable
private fun EdgeApp() {
    var timeframe by remember { mutableStateOf("M15") }
    var mode by remember { mutableStateOf("Balanced") }
    var status by remember { mutableStateOf("WAIT") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent,
        background = Bg,
        surface = Panel,
        onBackground = Color.White,
        onSurface = Color.White
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Bg)
                .verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("EDGE", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("SHARP ENTRY  •  XAUUSD", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Surface(color = Panel, shape = RoundedCornerShape(50)) {
                    Text("V2 • BUILD 0.1", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Muted, fontSize = 10.sp)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("MARKET PRICE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("XAUUSD", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Belum disambungkan", color = Color(0xFFFFC857), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Harga live Valetax belum tersedia. Aplikasi tidak memaparkan harga rekaan.", color = Muted, fontSize = 12.sp)
                    HorizontalDivider(color = Color(0xFF2A3550))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Metric("BROKER", "Valetax")
                        Metric("SIGNAL", status)
                        Metric("MODE", mode)
                    }
                }
            }

            Text("TIMEFRAME", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("M5", "M15", "M30", "H1").forEach { tf ->
                    FilterChip(
                        selected = timeframe == tf,
                        onClick = { timeframe = tf },
                        label = { Text(tf) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = Bg
                        )
                    )
                }
            }

            Text("SIGNAL MODE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Balanced", "Fast").forEach { m ->
                    FilterChip(
                        selected = mode == m,
                        onClick = { mode = m },
                        label = { Text(m) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = Bg
                        )
                    )
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("TRADE PLAN", Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold)
                        Surface(color = Color(0xFF3B3340), shape = RoundedCornerShape(8.dp)) {
                            Text("WAIT", Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = Color(0xFFFFC857), fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("Entry   —", color = Muted)
                    Text("Stop Loss   —", color = Muted)
                    HorizontalDivider(color = Color(0xFF2A3550))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Metric("TP1", "—")
                        Metric("TP2", "—")
                        Metric("TP3", "—")
                    }
                    Text("Signal hanya boleh dikira selepas data candle sebenar disambungkan dan diuji.", color = Muted, fontSize = 12.sp)
                }
            }

            OutlinedButton(
                onClick = { status = "WAIT" },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent)
            ) { Text("SEMAK SETUP") }

            Text(
                "Peringkat awal: UI Android disediakan. Sambungan feed Valetax/MT5, enjin signal, carta candle dan ujian APK masih belum siap.",
                color = Muted, fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun Metric(title: String, value: String) {
    Column(
        modifier = Modifier.weight(1f).background(Color(0xFF202A42), RoundedCornerShape(10.dp)).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(title, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
